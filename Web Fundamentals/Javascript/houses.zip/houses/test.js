function titles(arr) {
  for (var key in arr) {
    console.log(arr[key])
  }
}

titles([
  "Lord of Storm's End",
  "Lord Paramount of the Stormlands"
]);
